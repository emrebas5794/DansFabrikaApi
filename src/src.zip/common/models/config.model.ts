export interface IConfig {
    saleStatus: boolean;
}