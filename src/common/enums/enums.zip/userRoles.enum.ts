export enum ERoles {
    STUDENT = -1,
    ADMIN = 1
}
