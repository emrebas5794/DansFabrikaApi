export enum ERoles {
    ADMIN = 1
}
