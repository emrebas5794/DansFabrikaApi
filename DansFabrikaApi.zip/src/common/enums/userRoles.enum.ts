export enum ERoles {
    BRANCH = 0,
    AREA = 1,
    COMPANY = 2,
    ADMIN = 3,
    SUPERADMIN = 4
}
