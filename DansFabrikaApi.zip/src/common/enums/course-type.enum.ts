export enum ECourseTypes {
    WORKSHOP = 0,
    KIDS = 1,
    ACADEMY = 2
}
