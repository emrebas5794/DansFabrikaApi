export enum EVerificationType {
    REGISTER = "register",
    FORGOT_PASSWORD = "forgot-password"
}
