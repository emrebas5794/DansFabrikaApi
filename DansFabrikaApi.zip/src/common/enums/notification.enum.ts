
export enum ENotificationStatus {
    DELETED = -1,
    SENDED = 0,
    READED = 1
}

export enum ENotificationType {
    SMS = 0,
    EMAIL = 1,
    NOTIFICATION = 2
}