export enum EStatus {
    DELETED = -1,
    INACTIVE = 0,
    ACTIVE = 1
}
