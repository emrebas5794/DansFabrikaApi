export enum ELogs {
    INFORMATION = 0,
    NOTICE = 1,
    WARNING = 2,
    ERROR = 3,
    ALERT = 4,
    DEBUG = 5,
    CRITIC = 6,
    EMERGENCY = 7
}
