import { ServerErrorFilter } from './server-error.filter';

describe('ServerErrorFilter', () => {
  it('should be defined', () => {
    expect(new ServerErrorFilter()).toBeDefined();
  });
});
