import { DtoCleaningPipe } from './dto-cleaning.pipe';

describe('DtoCleaningPipe', () => {
  it('should be defined', () => {
    expect(new DtoCleaningPipe()).toBeDefined();
  });
});
