import { VerificationGuard } from './verification.guard';

describe('VerificationGuard', () => {
  it('should be defined', () => {
    expect(new VerificationGuard()).toBeDefined();
  });
});
