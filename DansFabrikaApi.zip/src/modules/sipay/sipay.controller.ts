import { Controller } from '@nestjs/common';

@Controller('sipay')
export class SipayController {
  constructor() {}
}
