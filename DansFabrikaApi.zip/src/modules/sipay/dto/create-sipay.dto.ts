export class CreateSipayDto {}
