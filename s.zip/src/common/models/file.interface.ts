

export interface IFile {
    fieldName: string;
    path?: string;
}