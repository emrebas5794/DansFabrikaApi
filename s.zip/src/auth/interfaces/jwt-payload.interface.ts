export interface JwtPayload {
    id: number,
    name: string,
    email: string,
    image: string,
    role: number,
    status: number
}